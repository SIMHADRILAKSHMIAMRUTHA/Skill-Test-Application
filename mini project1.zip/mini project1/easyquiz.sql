-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2021 at 12:46 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `easyquiz`
--

CREATE TABLE `easyquiz` (
  `qid` int(2) NOT NULL,
  `question` varchar(500) NOT NULL,
  `op1` varchar(100) NOT NULL,
  `op2` varchar(100) NOT NULL,
  `op3` varchar(100) NOT NULL,
  `op4` varchar(100) NOT NULL,
  `aid` varchar(50) NOT NULL,
  `explanation` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `easyquiz`
--

INSERT INTO `easyquiz` (`qid`, `question`, `op1`, `op2`, `op3`, `op4`, `aid`, `explanation`) VALUES
(1, 'A person crosses a 600 m long street in 5 minutes. What is his speed in km per hour?\r\n', '3.6', '7.2', '8.4', '10', 'op2', 'Speed = 600/ 5 x 60 m/sec. = 2 m/sec. = 2 x 18/5km/hr =7.2 km/hr'),
(2, 'Worker A takes 8 hours to do a job. Worker B takes 10 hours to do a job. How long should it take both A and B, working together to do the same job?\r\n', '4/9', '2 4/9', '3 4/9', '4 4/9', 'op4', 'In this type of questions, first we need to calculate 1 hours work, then their collective work as A\'s 1-hour work is 1/8\r\nB\'s 1-hour work is 1/10\r\n(A+B)\'s 1 hour work = 1/8 + 1/10= 9/40\r\nSo both will finish the work in 40/9 hours=4 4/9'),
(3, ' A train running at the speed of 60 km/hr crosses a pole in 9 seconds. What is the length of the train?\r\n', '120 meters', '180 meters', '150 meters', '324 meters', 'op3', 'Speed= 60 x5/18 m/sec= 50/3 m/sec.\r\nLength of the train = (Speed x Time).\r\nLength of the train = 50/3x 9m = 150 m.'),
(4, ' A and B started a business by investing Rs.4000/- and Rs.5000/- respectively. Find the A’s share out of a total profit of Rs.1800:\r\n', 'Rs.1000/-', 'Rs.1800/-', 'Rs.800/-', 'Rs.400/-', 'op3', 'A = Rs.4000/-\r\nB = Rs.5000/-\r\nA share 4 parts & B share 5 parts\r\nTotal 9 parts -----> Rs.1800/-\r\n----> 1 part -------> Rs.200/-\r\nA share = 4 parts -----> Rs.800/-'),
(5, 'A mixture contains alcohol and water in the ratio 4 : 3. If 5 liters of water is added to the mixture, the ratio becomes 4: 5. Find the quantity of alcohol in the given mixture.\r\n', '10', '12', '15', '18', 'op1', 'Let the quantity of alcohol and water be 4x litres and 3x litres respectively\r\n\r\n4x/(3x+5) = 4/5\r\n20x = 4(3x+5)\r\n8x = 20\r\nx = 2.5\r\nQuantity of alcohol = (4 x 2.5) litres = 10 litres.'),
(6, 'A boat can travel with a speed of 13 km/hr in still water. If the speed of the stream is 4 km/hr, find the time taken by the boat to go 68 km downstream.\r\n', '2 hours', '3 hours', '4 hours', '5 hours', 'op3', 'Speed downstream = (13 + 4) km/hr = 17 km/hr.\r\nTime taken to travel 68 km downstream =68/17hrs = 4 hrs.'),
(7, 'A sum of money at simple interest amounts to Rs. 815 in 3 years and to Rs. 854 in 4 years. The sum is:\r\n', '650', '690', '698', '700', 'op3', 'S.I. for 1 year = Rs. (854 - 815) = Rs. 39.\r\nS.I. for 3 years = Rs.(39 x 3) = Rs. 117.\r\nPrincipal = Rs. (815 - 117) = Rs. 698.'),
(8, 'The sides of a rectangle are in the ratio of 6: 5 and its area is 1331 sq.m. Find the perimeter of a rectangle.', '120 meters', '121 centimeter', '121 meter', 'None of these', 'op3', 'Let 6x and 5x be sides of the rectangle\r\n6x × 5x = 1331\r\n11x2 = 1331\r\nx2 = 1331/11 = 121 => x = 11\r\nLength = 6x = 6 × 11 = 66\r\nBreadth = 5x => 5 × 11 = 55\r\nPerimeter = 2 (l+b) => 2 (66+55) = 121 m'),
(9, 'The average of runs of a cricket player of 10 innings was 32. How many runs must he make in his next innings so as to increase his average of runs by 4?\r\n', '76', '79', '85', '87', 'op1', 'Average = total runs / no.of innings = 32\r\nSo, total = Average x no.of innings = 32 x 10 = 320.\r\nNow increase in avg = 4runs. So, new avg = 32+4 = 36runs\r\nTotal runs = new avg x new no. of innings = 36 x 11 = 396\r\nRuns made in the 11th inning = 396 - 320 = 76'),
(10, 'The greatest number which on dividing 1657 and 2037 leaves remainders 6 and 5 respectively, is:', '127', '305', '235', '123', 'op1', 'Required number = H.C.F. of (1657 - 6) and (2037 - 5)\r\n= H.C.F. of 1651 and 2032 = 127.'),
(11, 'Pipes A and B can fill a tank in 5 and 6 hours respectively. Pipe C can empty it in 12 hours. If all the three pipes are opened together, then the tank will be filled in:\r\n', ' 3 9/17 hours', '1 13/17 hours', '2 8/11 hours', '4 1/2 hours', 'op1', 'Pipes A and B can fill the tank in 5 and 6 hours respectively. Therefore,\r\npart filled by pipe A in 1 hour =1/5\r\npart filled by pipe B in 1 hour = 1/6\r\nPipe C can empty the tank in 12 hours. Therefore,\r\npart emptied by pipe C in 1 hour =1/12\r\nNet part filled by Pipes A,B,C together in 1 hour=1/5+1/6-1/12=17/60\r\ni.e., the tank can be filled in 60/17=3 9/17 hours.'),
(12, 'If one-third of one-fourth of a number is 15, then three-tenth of that number is:\r\n', '35', '36', '45', '54', 'op4', 'Let the number be x.\r\nThen,1/3of 1/4of x = 15\r\nx = 15 x 12 = 180.\r\nSo, required number = 3/10 x 180 = 54.'),
(13, 'Find compound interest on Rs. 8000 at 15% per annum for 2 years 4 months, compounded annually\r\n', '2109', '3109', '4109', '6109', 'op2', 'Time = 2 years 4 months = 2(4/12) years = 2(1/3) years.\r\nAmount = Rs\'. [8000 X (1+(15/100))^2 X (1+((1/3)*15)/100)]\r\n=Rs. [8000 * (23/20) * (23/20) * (21/20)]\r\n= Rs. 11109. .\r\n:. C.I. = Rs. (11109 - 8000) = Rs. 3109.'),
(14, ' A hall is 15 m long and 12 m broad. If the sum of the areas of the floor and the ceiling is equal to the sum of the areas of four walls, the volume of the hall is:\r\n', '720', '900', '1200', '1800', 'op3', '2(15 + 12) x h = 2(15 x 12)\r\nh =180/27m =20/3m.\r\nVolume = (15 x 12 x 20/3) m3= 1200 m3.'),
(15, 'If selling price is doubled the profit triples. Find the profit percent.\r\n', '66 2/3', '105', '105 1/3', '120', 'op2', 'Let C.P be Rs. x and S.P be Rs. y.\r\nThen, 3(y-x) = (2y-x) y = 2x.\r\nProfit = Rs.(y-x) = Rs.(2x-x) = Rs. x.\r\nProfit % = [(x/x)*100]% = 100%'),
(16, '1. 3, 5, 11, 14, 17, 21 ,find odd man out?', '21', '17', '14', '3', 'op3', 'Each of the numbers except 14 is an odd number. The number \'14\' is the only EVEN number.'),
(17, 'Karan and Arjun run a 100-meter race, where Karan beats Arjun by 10 meters. To do a favour to Arjun, Karan starts 10 meters behind the starting line in a second 100-meter race. They both run at their earlier speeds. Which of the following is true in connection with the second race?\r\n ', 'Karan and Arjun reach the finishing line simultaneously', 'Arjun beats Karan by 1 meter', 'Arjun beats Karan by 11 meters', 'Karan beats Arjun by 1 meter', 'op4', 'In a 100 meters race, when Karan runs 100 meters, Arjun runs 90 meters. Since time is constant, the ratio of distances is equal to the ratio of speeds. So, the ratio of speeds of Karan and Arjun is 100:90 = 10:9. In the second case, Karan will have to run 110 meters to complete the race. In this case, the ratio of distances travelled will be equal to the ratio of speeds 10:9. So, when Karan runs 110 meters, Arjun will run (110 x 9)/10 = 99 meters, i.e., he needs to cover 1 meter to complete the '),
(18, 'A train travelling at 60 kmph crosses a man in 6 seconds. What is the length of the train?\r\n', '100 meters', '150 meters', '200 meters', '250 meters', 'op1', 'Speed in m/sec = 60 *(5/18) = 50/3 m/sec\r\nTime taken to cross the man = 6 secs\r\nTherefore, Distance = (50/3)* 6 = 100 metres (i.e. the length of the train)'),
(19, 'In what ratio,water must be mixed with fruit juice costing Rs.24 per litre so that the juice would be worth of Rs.20 per litre?\r\n', '1:4', '1:5', '1:6', '2:5', 'op2', 'Cost of 1 litre of water = Rs.0 = cheaper quantity.\r\nCost of 1 litre of juice = Rs.24 = dearer quantity.\r\nAnd, the mean price = m = Rs.20\r\nTherefore, (Cheaper quantity) : (Dearer quantity) = (d - m) : (m - c) = 4:20 = 1:5\r\nHence, the required answer is 1:5.'),
(20, 'A fruit seller had some apples. He sells 40% apples and still has 420 apples. Originally, he had:\r\n', '588 apples', '600 apples', '672 apples', '700 apples', 'op4', 'Suppose originally he had x apples.\r\nThen, (100 - 40)% of x = 420.\r\n60/100 x x = 420\r\nx = 420 x 100/60 = 700.'),
(21, 'Solve the equation for x : 19(x + y) + 17 = 19(-x + y) - 21\r\n', '-1', '-2', '-3', '-4', 'op1', '19x + 19y + 17 = -19x + 19y - 21\r\n38x = -38 => x = -1'),
(22, 'The sum and the product of the roots of the quadratic equation x2 + 20x + 3 = 0 are?', '10,3', '-10,3', '20,-3', 'None of these', 'op4', 'Sum of the roots and the product of the roots are -20 and 3 respectively.'),
(23, 'A boy has nine trousers and 12 shirts. In how many different ways can he select a trouser and a shirt?\r\n', '21', '12', '9', '108', 'op4', 'The boy can select one trouser in nine ways.\r\nThe boy can select one shirt in 12 ways.\r\nThe number of ways in which he can select one trouser and one shirt is 9 * 12 = 108 ways.'),
(24, 'Sam and Joan are playing a tennis match. If the probability of Sam\'s win is 0.59, then find the probability of Joan\'s win.\r\n', '0.47', '0.36', '0.41', '0.25', 'op3', 'Let event A = Sam wins and event B = Joan wins. Then,\r\nP(A) = 0.59\r\nSince if Sam wins, Joan cannot win and if Joan wins, Sam cannot win, so we can say that the events A and B are mutually exclusive. Other than these two events, there are\r\nno any other possible outcomes. So,\r\nP(A)+P(B) = 1\r\n0.59+P(B) = 1\r\nP(B) = 1-0.59 = 0.41'),
(25, 'Find the sum of all the 4 digit numbers that can be formed with the digits 3, 4, 5 and 6\r\n', '119988', '11988', '191988', 'None of these', 'op1', 'No. of Digits = 4 All are distinct; They can be arranged in 4! = 24 ways\r\nEach of the digits 3, 4, 5 and 6 occur at unit place = 3! Ways = 6 ways.\r\nThus there will be 6 numbers ending with 3, 4, 5 and 6 each. So the sum of the digits at unit\'s place = 6(3 + 4 + 5 + 6) =108\r\nThe sum of numbers = 108 × 103 + 108 × 102 + 108 × 101 + 108 × 100 = 119988\r\n\r\n'),
(26, ' A and B can together complete a piece of work in 4 days. If A alone can complete the same work in 12 days, in how many days can B alone complete that work?\r\n', '4 days', '5 days', '6 days', '7 days', 'op3', '(A+B)\'s 1 day work = 1/4\r\nA\'s 1 day work = 1/12\r\nB\'s 1 day work = (1/4-1/12)=3-1/12=1/6.\r\nSo B alone can complete the work in 6 days'),
(27, 'Find the odd man out: 3, 7, 15, 17, 22, 27, 29.\r\n', '17', '22', '15', '27', 'op2', 'Each of the numbers is odd number except 22. The number \'22\' is the only even number.'),
(28, ' Determine the probability that a digit chosen at random from the digits 1, 2, 3, …12 will be odd.\r\n', '1/2', '1/9', '5/9', '4/9', 'op1', 'Total no. of Digits = 12. Equally likely cases = 12.\r\nThere are six odd digits. Probability = 6 / 12 = 1 / 2'),
(29, 'Find the number of words, with or without meaning, that can be formed with the letters of the word ‘SWIMMING?\r\n', '10080', '4569', '9800', '2478', 'op1', 'The word ‘SWIMMING contains 8 letters. Of which, I occurs twice and M occurs twice. Therefore, the number of words formed by this word = 8! / (2!*2!) = 10080.'),
(30, 'The sum of ages of 5 children born at the intervals of 3 years each is 50 years. What is the age of the youngest child?\r\n', '4 years', '8 years', '10 years', 'None of these', 'op1', 'Let the ages of children be x, (x + 3), (x + 6), (x + 9) and (x + 12) years.\r\nThen, x + (x + 3) + (x + 6) + (x + 9) + (x + 12) = 50\r\n5x = 20\r\nx = 4.\r\nAge of the youngest child = x = 4 years.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `easyquiz`
--
ALTER TABLE `easyquiz`
  ADD PRIMARY KEY (`qid`),
  ADD UNIQUE KEY `question` (`question`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
