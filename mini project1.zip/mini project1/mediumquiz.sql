-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2021 at 12:53 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `mediumquiz`
--

CREATE TABLE `mediumquiz` (
  `qid` int(3) NOT NULL,
  `question` varchar(500) NOT NULL,
  `op1` varchar(50) NOT NULL,
  `op2` varchar(50) NOT NULL,
  `op3` varchar(50) NOT NULL,
  `op4` varchar(50) NOT NULL,
  `aid` varchar(50) NOT NULL,
  `explanation` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mediumquiz`
--

INSERT INTO `mediumquiz` (`qid`, `question`, `op1`, `op2`, `op3`, `op4`, `aid`, `explanation`) VALUES
(1, ' The average weight of P, Q and R is 45 kg. If the average weight of P and Q is 40 kg and that of Q and R is 43 kg, what is the weight of Q?\r\n', '32', '65', '67', '31', 'op4', 'Let P, Q, R represent their respective weights. Then, we have:\r\nP + Q + R = (45 x 3) = 135.... (i)\r\nP + Q = (40 x 2) = 80.... (ii)\r\nQ + R = (43 x 2) = 86.... (iii)\r\nAdding (ii) and (iii), we get: P + 2Q + R = 166.... (iv)\r\nSubtracting (i) from (iv), we get: Q = 31.'),
(2, ' RQP, ONM, _, IHG, FED, find the missing letters.\r\n', 'CDE', 'LKI', 'LKJ', 'BAC', 'op3', 'The series consists of letters in reverse alphabetical order. Therefore, the missing letters are LKJ'),
(3, ' Three years ago, the average age of Anita, Priya, and Varsha was 27 years. If five years ago, the average age of Priya and Varsha was 20 years, find the present age of Anita.\r\n', '30', '40', '60', '25', 'op2', 'Sum of the present ages of Anita, Priya and Varsha = (27 x 3 + 3 x 3) years = 90 years.\r\nSum of the present ages of Priya and Varsha = (20 x 2 + 5 x 2) years = 50 years.\r\nAnita\'s present age = (90 - 50) years = 40 years.'),
(4, ' A museum has an average of 510 visitors on Sunday and 240 on other days. Find the average number of visitors per day in a month of 30 days beginning with a Sunday', '285 ', '275', ' 237 ', '245', 'op1', 'Since, the month begins with a Sunday, so there will be 5 Sundays and 25 other days in this month. \r\nSo, the average no. of visitor per day\r\nAverage Aptitude\r\n= 285'),
(5, 'In a class average age of 15 boys is 11. If 5 boys each of age 9 years are added, what would be the new average?\r\n', '20 years', '10 years', '10.5 years', '23 years', 'op3', 'Sum of ages of 15 boys = 15*11=165\r\nSum of ages of 5 boys = 5*9 =45\r\nTotal age of 20 boys = 165+45 = 210\r\nAverage of ages of 20 boys = 210/20= 10.5 years'),
(6, '10 typists can type 600 pages in 8 hours.Find the average number of pages typed by each typist in an hour.\r\n', '7 pages', '7.5 pages', '8 pages', '8.5 pages', 'op2', 'Total pages typed by 10 typists in 8 hours = 600\r\nPages typed by one typist in 8 hours = 600/10  = 60 pages\r\nPages typed by one typist in one hour = 60/8  = 7.5 pages'),
(7, 'Find the average of cubes of first 7 consecutive natural numbers.', '112', '110', '116', '113', 'op1', 'The average of cubes of first n consecutive natural numbers is given by; \r\n= n (n+1)²/4 \r\nHere, n=7\r\n= 7 (7+1)²/4 \r\n= 7*64/4\r\n=448/4\r\n= 112'),
(8, 'The average age of 30 boys in a class is 15 years. If we include the age of two teachers the average age increases by 1. Find the sum of ages of the two teachers.', '55 years', '58 years', '62 years', '64 years', 'op3', 'Total age of 30 boys would be = 30?15 = 450 years\r\nTotal age of 30 boys and 2 teachers would be = 32?16= 512 years\r\n? Sum of ages of two teachers would be = 512 - 450 = 62 years'),
(9, 'A watch which gains uniformly is 2 minutes low at noon on Monday and is 4 min. 48 sec fast at 2 p.m. on the following Monday. When was it correct?', '2 p.m. on Tuesday', '2 p.m. on Wednesday', '3 p.m. on Thursday', '1 p.m. on Friday', 'op2', 'Time from 12 p.m. on Monday to 2 p.m. on the following Monday = 7 days 2 hours = 170 hours.The watch gains 2 + (4 4/5)min or 34/5 min. in 170 hrs.\r\nNow, 34/5 min are gained in 170 hrs.\r\n 2 min are gained in (170 x5/34	x 2)hrs	= 50 hrs.Watch is correct 2 days 2 hrs. after 12 p.m. on Monday i.e., it will be correct at 2 p.m. on Wednesday.'),
(10, 'On what dates of April, 2001 did Wednesday fall?', '1st, 8th, 15th, 22nd, 29th', '2nd, 9th, 16th, 23rd, 30th', '3rd, 10th, 17th, 24th', '4th, 11th, 18th, 25th', 'op4', 'We shall find the day on 1st April, 2001.\r\n1st April, 2001 = (2000 years + Period from 1.1.2001 to 1.4.2001)\r\nOdd days in 1600 years = 0\r\nOdd days in 400 years = 0\r\nJan. Feb. March April\r\n(31 + 28 + 31 + 1)     = 91 days  0 odd days.\r\n\r\nTotal number of odd days = (0 + 0 + 0) = 0\r\n\r\nOn 1st April, 2001 it was Sunday.\r\n\r\nIn April, 2001 Wednesday falls on 4th, 11th, 18th and 25th.'),
(11, 'Seats for Mathematics, Physics and Biology in a school are in the ratio 5 : 7 : 8. There is a proposal to increase these seats by 40%, 50% and 75% respectively. What will be the ratio of increased seats?', '2:3:4', '6:7:8', '6:8:9', 'None of these', 'op1', 'Originally, let the number of seats for Mathematics, Physics and Biology be 5x, 7x and 8x respectively.Number of increased seats are (140% of 5x), (150% of 7x) and (175% of 8x).\r\n(140/100*5x),(150/100x 7x)and (175/100* 8x)	\r\n 7x,21x/2and 14x.\r\nThe required ratio = 7x :21x/2: 14x\r\n 14x : 21x : 28x\r\n2 : 3 : 4.'),
(12, 'What will be the cost of gardening 1-meter boundary around a rectangular plot having a perimeter of 340 meters at the rate of Rs. 10 per square meter?', 'Rs.3430', 'Rs.3440', 'Rs.3450', 'Rs.3460', 'op2', 'In this question, we are having a perimeter.\r\nWe know Perimeter = 2(l+b), right\r\nSo,\r\n2(l+b) = 340\r\nAs we have to make 1 meter boundary around this, so\r\nArea of boundary = ((l+2)+(b+2)-lb)\r\n= 2(l+b)+4 = 340+4 = 344\r\nSo required cost will be = 344 * 10 = 3440\r\n\r\n'),
(13, 'A metallic sheet is of rectangular shape with dimensions 48 m x 36 m. From each of its corners, a square is cut off so as to make an open box. If the length of the square\r\nis 8 m, the volume of the box (in m3) is:\r\n', '4830', '5120', '6420', '8960', 'op2', 'Clearly, l = (48 - 16)m = 32 m,\r\nb = (36 -16)m = 20 m,\r\nh = 8 m.\r\nVolume of the box = (32 x 20 x 8) m3 = 5120 m3.'),
(14, 'A is twice as good a workman as B and is therefore able to finish a piece of work in 30 days less than B.In how many days they can complee the whole work; working together?\r\n', '10 Days', '20 Days', '30 Days', '40 Days', 'op2', 'Ratio of times taken by A and B = 1 : 2.\r\nThe time difference is (2 - 1) 1 day while B take 2 days and A takes 1 day.\r\nIf difference of time is 1 day, B takes 2 days.\r\nIf difference of time is 30 days, B takes 2 x 30 = 60 days.\r\nSo, A takes 30 days to do the work.\r\nA\'s 1 day\'s work = 1/30\r\nB\'s 1 day\'s work = 1/60\r\n(A + B)\'s 1 day\'s work = 1/30 + 1/60 = 1/20\r\nA and B together can do the work in 20 days.'),
(15, ' When twice the original number is divided by the same divisor, the remainder is 11. What is the value of the divisor?\r\n', '13', '59', '35', '37', 'op4', 'Let the original number be \'a\'.Let the divisor be \'d\'.Let the quotient of the division of a by d be \'x\'.Therefore, we can write the relation as a/d=x and the remainder is 24. i.e., a=dx+24.When twice the original number is divided by d,2a is divided by d.\r\nWe know that a=dx+24. Therefore, 2a=2dx+48.The problem states that (2dx+48)/d leaves a remainder of 11.2dx is perfectly divisible by d and will, therefore, not leave a remainder.The remainder of 11 was obtained by dividing 48 by d.\r\nWhen 48 is divided by 37, the remainder that one will obtain is 11.Hence, the divisor is 37.'),
(16, 'An electronic device makes a beep after every 60 sec. Another device makes a beep after every 62 sec. They beeped together at 10 a.m. The time when they will next make\r\na beep together at the earliest, is\r\n', '10:28 am', '10 : 30 am', '10 :31 am', 'None of these', 'op3', 'L.C.M. of 60 and 62 seconds is 1860 seconds\r\n1860/60 = 31 minutes\r\nThey will beep together at 10:31 a.m.\r\nSometimes questions on red lights blinking comes in exam, which can be solved in the same way'),
(17, 'An express train travelled at an average speed of 100 km/hr, stopping for 3 minutes after every 75 km. How long did it take to reach its destination 600 km from the starting point?\r\n', '6 hrs 27 min', '6 hrs 24 min', '6 hrs 21 min', '6 hrs  30 min', 'op3', 'Time taken to cover 600 km = (600/100)hrs =6 hrs.\r\nNumber of stoppages = 600/75 - 1 =7.\r\nTotal Time of stoppages= (3 x 7)min=21 min.\r\nHence, total time taken=6 hrs 21 min.'),
(18, 'A and B together can complete a task in 20 days. B and C together can complete the same task in 30 days. A and C together can complete the same task in 30 days. What is the respective ratio of the number of days taken by A when completing the same task alone to the number of days taken by C when completing the same task alone?', '1:3', '  2:4 ', '  3:1 ', '4:5', 'op1', 'Efficiency of A and B = 1/20 per day = 5% per day ________________1\r\nEfficiency of B and C = 1/30 per day = 3.33% per day______________2\r\nEfficiency of C and A = 1/30 per day = 3.33% per day______________3\r\nTaking equation 2 and 3 together\r\nB + C = 3.33% and C + A = 3.33%\r\nC and 3.33% will be removed. Hence A = B\r\nEfficiency of A = B = 5%/2 = 2.5% = 1/40\r\nEfficiency of C = 3.33% - 2.5% = 0.833% = 1/120\r\nA can do the job in 40 days and C can do the job in 120 days he they work alone.\r\nRatio of number of days in which A and C can complete the job 1:3.'),
(19, 'A boat sails 15 km of a river towards upstream in 5 hours. How long will it take to cover the same distance downstream, if the speed of the current is one-fourth the speed of the boat in still water:\r\n', '1.8h', '3h4h', '4h', '5h', 'op2', 'Upstream speed = B-S\r\nDownstream speed = B+s\r\nB-S = 15/5 = 3 km/h\r\nAgain B= 4S\r\nTherefore B-S = 3= 3S\r\n=>S = 1 and B= 4 km/h\r\nTherefore B+S = 5km/h\r\nTherefore, Time during downstream = 15/5 = 3h'),
(20, '12 buckets of water fill a tank when the capacity of each tank is 13.5 litres. How many buckets will be needed to fill the same tank, if the capacity of each bucket is 9 litres?', '15 buckets', '17 buckets', '18 buckets', '19 buckets', 'op3', 'Capacity of the tank = (12*13.5) litres = 162 litres\r\nCapacity of each bucket = 9 litres.\r\nSo we can get an answer by dividing total capacity of a tank by total capacity of a bucket.\r\nNumber of buckets needed = (162/9) = 18 buckets'),
(21, 'There is 80% increase in an amount in 8 years at simple interest. What will be the compound interest of 80% increase in an amount in 8 years at simple interest? What will be the compound interest of Rs. 14,000 after 3 years at the same rate?\r\n', '3794', '3714', '4612', '4634', 'op4', 'Let P = Rs.100\r\nSimple Interest = Rs. 80 ( ? 80% increase is due to the simple interest)\r\nRate of interest=(100×SI)/PT=(100×80)/(100×8) =10% per annum\r\nNow let\'s find out the compound interest of Rs. 14,000 after 3 years at 10%\r\nP = Rs.14000\r\nT = 3 years\r\nR = 10%\r\nAmount after 3 years =P(1+R/100)^T\r\n=14000(1+10/100)^3\r\n=14000(110/100)^3\r\n=14000(11/10)^3\r\n=14×11^3=18634.\r\nCompound Interest = Rs.18634 - Rs.14000 = Rs.4634'),
(22, 'A manufacturing company employs 10 machines, the aggregate output of which for a year is Rs 42000, and pays 10% of the profit to its shareholders. The manufacturing expenses for a year are Rs.1800 per machine and the establishment charges Rs 9000 per annum. What percent of the original profit will it pay to its shareholders, if one machine breaks down and are idle for one year?\r\n', '7 3/10 %', '3%', '8 2/5%', '9 1/3%', 'op3', 'When all 10 machines are working, profit =42000-[9000-(1800*10)] = Rs.15000.\r\nIf one breaks down, then the aggregate output = 0.9*42000 = Rs.37800,\r\nManufacturing expenses = Rs 16200,\r\nEstablishment charges = Rs.9000 Therefore Total expenses = Rs. 25200,\r\nProfit = Rs.37800- Rs.25200 = Rs. 12600\r\nThe profit paid to shareholder is 10% of Rs 12600 = 1260\r\nRequired percentage = 1260*100/15000 = 8 2/5 %'),
(23, '19, 28, 39, 52, 67, 84, 102 find odd one out\r\n ', '52', '102', '84', '67', 'op2', 'Here, pattern is x^2 + 3, where x = 4, 5, 6, 7, 8, etc. But 102 is out of p'),
(24, 'In a 200m race, if A gives B a start of 25 meters, then A wins the race by 10 seconds. Alternatively, if A gives B a start of 45 meters the race ends in a dead heat. How long does A take to run 200m?\r\n', '100 seconds', '112.5 seconds', '77.5 seconds', '87.5 seconds', 'op3', 'A gives B a start of 25 meters and still wins the race by 10 seconds.\r\nAlternatively, if A gives B a start of 45 meters, then the race ends in a dead heat.\r\nTherefore, the additional 20 meters start given to B compensates for the 10 seconds.i.e., B runs 20 meters in 10 seconds.\r\nHence, B will take 100 seconds to run 200 meters.\r\nWe know that A gives B a start of 45 meters. B will take 22.5 seconds to run this 45 meters as B runs 20 meters in 10 seconds or at the speed of 2 m/s.\r\nHence, A will take 22.5 seconds lesser than B or 100 - 22.5 = 77.5 seconds to complete the race.'),
(25, ' Two varieties of wheat - A and B costing Rs. 9 per kg and Rs. 15 per kg were mixed in the ratio 3 : 7. If 5 kg of the mixture is sold at 25% profit, find the profit made?\r\n', 'Rs.13.50', 'Rs.14.50', 'Rs.15.50', 'Rs.16.50', 'op4', 'Let the quantities of A and B mixed be 3x kg and 7x kg.Cost of 3x kg of A = 9(3x) = Rs. 27x\r\nCost of 7x kg of B = 15(7x) = Rs. 105x\r\nCost of 10x kg of the mixture = 27x + 105x = Rs. 132x\r\nCost of 5 kg of the mixture = 132x/10x (5) = Rs. 66\r\nProfit made in selling 5 kg of the mixture = 25/100 (cost of 5 kg of the mixture) = 25/100 * 66 = Rs. 16.50'),
(26, 'Using only 2, 5, 10, 25 and 50 paise coins, what will be the minimum number of coins required to pay exactly 78 paise, 69 paise, and Re. 1.01 to three different persons?\r\n', '19', '20', '17', '1', 'op1', 'As we need the minimum number of coins go for the highest denomination first\r\n78 -- > 50 + 2 x 10 + 4 x 2 (7 coins)\r\n69 -- > 50 + 10 + 5 + 2 x 4 (5 coins)\r\n1.01 -- > 50 + 25 + 2 x 10 + 3 x 2 (7 Coins)\r\nTotal = 7 + 5 + 7 = 19 coins.'),
(27, 'A 5 cubic centimeter cube is painted on all its side. If it is sliced into 1 cubic centimeter cubes, how many 1 cubic centimeter cubes will have exactly one of their sides painted?\r\n', '9', '61', '98', '54', 'op4', 'When a 5 cc cube is sliced into 1 cc cubes, we will get 5*5*5 = 125 1 cc cubes.\r\nIn each side of the larger cube, the smaller cubes on the edges will have more than one of their sides painted.Therefore, the cubes which are not on the edge of the larger cube and that lie on the facing sides of the larger cube will have exactly one side painted.\r\nIn each face of the larger cube, there will be 5*5 = 25 cubes. Of these, there will be 16 cubes on the edge and 3*3 = 9 cubes which are not on the edge.Therefore, there will be 9 1-cc cubes per face that will have exactly one of their sides painted.In total, there will be 9*6 = 54 such cubes.'),
(28, ' How many combinations of students are possible if the group is to consist of exactly 3 freshmen?', '5000', '4550', '4000', '3550', 'op2', 'Here we need the number of possible combinations of 3 out of 5 freshmen,5C3, and the number of possible combinations of 3 out of the 15 sophomores and juniors,\r\n15C3. Note that we want 3 freshmen and 3 students from the other classes. Therefore, we multiply the number of possible groups of 3 of the 5 freshmen times the number of possible groups of 3 of the 15 students from the other classes. 5C3×15C3=4,550.'),
(29, 'Tickets numbered 1 to 20 are mixed up and then a ticket is drawn at random. What is the probability that the ticket drawn has a number which is a multiple of 3 or 5?\r\n', '1/2', '2/5', '8/15', '9/20', 'op4', 'Here, S = {1, 2, 3, 4, ...., 19, 20}.\r\nLet E = event of getting a multiple of 3 or 5 = {3, 6 , 9, 12, 15, 18, 5, 10, 20}.\r\nP(E) = n(E)/n(S) = 9/20.'),
(30, ' A man has Rs. 480 in the denominations of one-rupee notes, five-rupee notes and ten-rupee notes. The number of notes of each denomination is equal. What is the total number of notes that he has?\r\n', '45', '60', '75', '90', 'op4', 'Let number of notes of each denomination be x.\r\nThen x + 5x + 10x = 480\r\n16x = 480\r\nx = 30.\r\nHence, total number of notes = 3x = 90.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mediumquiz`
--
ALTER TABLE `mediumquiz`
  ADD PRIMARY KEY (`qid`),
  ADD UNIQUE KEY `question` (`question`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
